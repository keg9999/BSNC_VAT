sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ns.bsncvat0000.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);